package com.felix.util;

public class Constants {
	public final static String SEX_MALE = "male";
	public final static String SEX_FEMALE = "female";
	public final static String CHAR_ENC = "UTF-8";
	public final static String NOT_AVAILABLE = "NA";

}
